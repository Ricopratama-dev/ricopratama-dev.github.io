<?php
session_start();

// kalau user belum login → redirect ke login.php
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit();
}

include 'includes/header.php';
include 'includes/koneksi.php';

// Ambil nama user
$stmtUser = $conn->prepare("SELECT nama FROM users WHERE id = ?");
$stmtUser->bind_param("i", $_SESSION['user_id']);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();
$user = $resultUser->fetch_assoc();
$nama_user = $user ? $user['nama'] : 'Pengguna';

// Ambil daftar belanja (status belum)
$stmt = $conn->prepare("SELECT * FROM daftar_belanja WHERE user_id=? AND status='belum'");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$belanja = $stmt->get_result();

// Ambil invoice (status selesai)
$stmt2 = $conn->prepare("SELECT * FROM daftar_belanja WHERE user_id=? AND status='selesai'");
$stmt2->bind_param("i", $_SESSION['user_id']);
$stmt2->execute();
$invoice = $stmt2->get_result();

// ===== Data Dashboard =====
$uid = $_SESSION['user_id'];

// Total pengeluaran bulan ini
$stmtBulan = $conn->prepare("SELECT COALESCE(SUM(harga),0) as total FROM daftar_belanja WHERE user_id=? AND status='dibayar' AND DATE_FORMAT(waktu_selesai,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m')");
$stmtBulan->bind_param("i", $uid);
$stmtBulan->execute();
$totalBulan = $stmtBulan->get_result()->fetch_assoc()['total'];

// Jumlah transaksi bulan ini
$stmtTrx = $conn->prepare("SELECT COUNT(DISTINCT DATE_FORMAT(waktu_selesai,'%Y-%m-%d %H:%i')) as total FROM daftar_belanja WHERE user_id=? AND status='dibayar' AND DATE_FORMAT(waktu_selesai,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m')");
$stmtTrx->bind_param("i", $uid);
$stmtTrx->execute();
$totalTrx = $stmtTrx->get_result()->fetch_assoc()['total'];

// Item terbanyak dibeli bulan ini
$stmtTop = $conn->prepare("SELECT nama_barang, COUNT(*) as jumlah FROM daftar_belanja WHERE user_id=? AND status='dibayar' AND DATE_FORMAT(waktu_selesai,'%Y-%m')=DATE_FORMAT(NOW(),'%Y-%m') GROUP BY nama_barang ORDER BY jumlah DESC LIMIT 1");
$stmtTop->bind_param("i", $uid);
$stmtTop->execute();
$topItem = $stmtTop->get_result()->fetch_assoc();
$namaTop = $topItem ? htmlspecialchars($topItem['nama_barang']) : '-';

// Total item pending di daftar
$totalPending = $belanja->num_rows;
$belanja->data_seek(0);

// Budget user
$stmtBudget = $conn->prepare("SELECT budget_bulanan FROM users WHERE id=?");
$stmtBudget->bind_param("i", $uid);
$stmtBudget->execute();
$budget = (float)$stmtBudget->get_result()->fetch_assoc()['budget_bulanan'];
$pctBudget = ($budget > 0) ? ($totalBulan / $budget * 100) : 0;
?>

<div class="mb-5 text-center">
  <h2 class="fw-bold">Haiii, <?php echo htmlspecialchars($nama_user); ?></h2>
  <p class="text-muted">Kelola kebutuhan belanja dengan cara yang lebih simpel & modern</p>
</div>

<!-- Dashboard Ringkasan -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4 text-center p-3">
      <div class="text-muted small mb-1"><i class="bi bi-wallet2 me-1"></i> Pengeluaran Bulan Ini</div>
      <div class="fw-bold fs-5 text-success">Rp <?= number_format($totalBulan, 0, ',', '.') ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4 text-center p-3">
      <div class="text-muted small mb-1"><i class="bi bi-receipt me-1"></i> Transaksi Bulan Ini</div>
      <div class="fw-bold fs-5 text-primary"><?= $totalTrx ?> kali</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4 text-center p-3">
      <div class="text-muted small mb-1"><i class="bi bi-bag me-1"></i> Item Pending</div>
      <div class="fw-bold fs-5 text-warning"><?= $totalPending ?> item</div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm rounded-4 text-center p-3">
      <div class="text-muted small mb-1"><i class="bi bi-star me-1"></i> Paling Sering Dibeli</div>
      <div class="fw-bold fs-6 text-info text-truncate"><?= $namaTop ?></div>
    </div>
  </div>
</div>

<?php if ($budget > 0): ?>
<?php
  $barColor = $pctBudget >= 100 ? 'bg-danger' : ($pctBudget >= 80 ? 'bg-warning' : 'bg-success');
  $barWidth = min($pctBudget, 100);
?>
<div class="card border-0 shadow-sm rounded-4 mb-4 px-4 py-3">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <span class="small fw-semibold">
      <i class="bi bi-piggy-bank me-1"></i> Budget Bulanan
      <?php if ($pctBudget >= 100): ?>
        <span class="badge bg-danger ms-1">Melebihi Budget!</span>
      <?php elseif ($pctBudget >= 80): ?>
        <span class="badge bg-warning text-dark ms-1">Mendekati Batas</span>
      <?php endif; ?>
    </span>
    <span class="small text-muted">
      Rp <?= number_format($totalBulan, 0, ',', '.') ?> / Rp <?= number_format($budget, 0, ',', '.') ?>
      (<?= number_format($pctBudget, 1) ?>%)
    </span>
  </div>
  <div class="progress rounded-pill" style="height:10px;">
    <div class="progress-bar <?= $barColor ?> rounded-pill" style="width:<?= $barWidth ?>%"></div>
  </div>
</div>
<?php endif; ?>

<div class="row g-4">
  <!-- Form Tambah Belanja -->
  <div class="col-lg-4">
    <div class="card border-0 shadow-lg rounded-4 h-100 hover-scale">
      <div class="card-body p-4">
        <h5 class="fw-bold mb-4">Tambah Item</h5>
        <form method="POST" action="proses.php" class="needs-validation" novalidate>
          <div class="form-floating mb-3">
            <input type="text" class="form-control rounded-3" id="nama_barang" name="nama_barang" placeholder="Nama Barang" required>
            <label for="nama_barang">Nama Barang</label>
          </div>
          <div class="form-floating mb-3">
            <input type="text" class="form-control rounded-3" id="jumlah_satuan" name="jumlah_satuan" placeholder="Contoh: 2 kg" required>
            <label for="jumlah_satuan">Jumlah & Satuan</label>
          </div>
          <div class="form-floating mb-4">
            <input type="number" class="form-control rounded-3" id="harga" name="harga" step="0.01" placeholder="Harga" required>
            <label for="harga">Harga Total</label>
          </div>
          <div class="form-floating mb-4">
            <select class="form-select rounded-3" id="kategori" name="kategori">
              <option value="Makanan">Makanan</option>
              <option value="Minuman">Minuman</option>
              <option value="Kebutuhan Rumah">Kebutuhan Rumah</option>
              <option value="Kebersihan">Kebersihan</option>
              <option value="Kesehatan">Kesehatan</option>
              <option value="Pakaian">Pakaian</option>
              <option value="Elektronik">Elektronik</option>
              <option value="Lainnya" selected>Lainnya</option>
            </select>
            <label for="kategori">Kategori</label>
          </div>
          <button type="submit" name="tambah" class="btn btn-success w-100 rounded-3 py-2">
            <i class="bi bi-plus-circle me-1"></i> Tambah
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- Daftar Belanja -->
  <div class="col-lg-8">
    <div class="card border-0 shadow-lg rounded-4 h-100 hover-scale">
      <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="fw-bold mb-0">Daftar Belanja</h5>
          <div class="d-flex align-items-center gap-2">
            <span class="badge bg-primary rounded-pill"><?php echo $belanja->num_rows; ?> Item</span>
            <?php if ($belanja->num_rows > 0): ?>
              <a href="#" class="btn btn-sm btn-outline-danger rounded-pill" id="btnKosongkan">
                <i class="bi bi-trash3 me-1"></i> Kosongkan
              </a>
            <?php endif; ?>
          </div>
        </div>

        <!-- Pencarian -->
        <div class="mb-3">
          <div class="input-group input-group-sm">
            <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
            <input type="text" id="cariBarang" class="form-control border-start-0 rounded-end-3" placeholder="Cari nama barang...">
          </div>
        </div>
        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
          <table class="table table-hover align-middle">
            <thead class="table-light">
              <tr>
                <th>No</th>
                <th>Barang</th>
                <th>Jumlah</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th class="text-center">Aksi</th>
              </tr>
            </thead>
            <tbody id="tabelBelanja">
              <?php
              if ($belanja->num_rows > 0) {
                $no = 1;
                while ($row = $belanja->fetch_assoc()) {
                  echo "<tr>
                <td>" . $no++ . "</td>
                <td>" . htmlspecialchars($row['nama_barang']) . "</td>
                <td>" . htmlspecialchars($row['jumlah_satuan']) . "</td>
                <td><span class='badge bg-secondary rounded-pill'>" . htmlspecialchars($row['kategori'] ?? 'Lainnya') . "</span></td>
                <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
                <td class='text-center'>
                    <div class='d-flex justify-content-center gap-2'>
                        <a href='edit.php?id=" . $row['id'] . "' class='btn btn-sm btn-outline-primary rounded-pill'>
                            <i class='bi bi-pencil'></i>
                        </a>
                        <a href='proses.php?selesai=" . $row['id'] . "' class='btn btn-sm btn-outline-success rounded-pill'>
                            <i class='bi bi-check2-circle'></i>
                        </a>
                        <a href='#' class='btn btn-sm btn-outline-danger rounded-pill btn-hapus' data-id='" . $row['id'] . "'>
                            <i class='bi bi-trash'></i>
                        </a>
                    </div>
                </td>
            </tr>";
                }
              } else {
                echo "<tr><td colspan='6' class='text-center text-muted'>Belum ada barang</td></tr>";
              }
              ?>
            </tbody>


          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Invoice Section -->
<div class="card border-0 shadow-lg rounded-4 mt-5 hover-scale">
  <div class="card-body p-4">
    <h5 class="fw-bold mb-3">Invoice</h5>
    <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
      <table class="table table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>No</th>
            <th>Barang</th>
            <th>Jumlah</th>
            <th>Harga</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $total = 0;
          if ($invoice->num_rows > 0) {
            $no = 1;
            while ($row = $invoice->fetch_assoc()) {
              $total += $row['harga'];
              echo "<tr>
                      <td>" . $no++ . "</td>
                      <td>" . htmlspecialchars($row['nama_barang']) . "</td>
                      <td>" . htmlspecialchars($row['jumlah_satuan']) . "</td>
                      <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
                    </tr>";
            }
            echo "<tr class='table-secondary fw-semibold'>
                    <td colspan='3' class='text-end'>Total</td>
                    <td>Rp " . number_format($total, 0, ',', '.') . "</td>
                  </tr>";
          } else {
            echo "<tr><td colspan='4' class='text-center text-muted'>Belum ada invoice</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>

    <?php if ($total > 0): ?>
      <div class="text-end mt-3">
        <button type="button" id="btnBayar" class="btn btn-primary rounded-3 px-4 py-2">
          <i class="bi bi-wallet2 me-1"></i> Bayar Sekarang
        </button>
      </div>
    <?php endif; ?>

  </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- SweetAlert2 dimuat PERTAMA sebelum dipakai -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
  /* Animasi Hover */
  .hover-scale {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  .hover-scale:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
  }

  /* Tabel */
  .table td,
  .table th {
    vertical-align: middle;
  }

  /* Header tabel */
  .table th {
    background-color: #e3f3fa;
    font-weight: 600;
    text-align: center;
    padding: 12px;
  }

  /* Nomor & aksi rata tengah */
  .table td:first-child,
  .table th:first-child,
  .table td:last-child,
  .table th:last-child {
    text-align: center;
    width: 80px;
  }

  /* Kolom jumlah rata kanan */
  .table td:nth-child(3),
  .table th:nth-child(3) {
    text-align: right;
    width: 150px;
  }

  /* Kolom harga rata kanan */
  .table td:nth-child(4),
  .table th:nth-child(4) {
    text-align: right;
    width: 180px;
    white-space: nowrap;
    /* Supaya Rp tetap di 1 baris */
  }

  /* Barang tetap rata kiri */
  .table td:nth-child(2),
  .table th:nth-child(2) {
    text-align: left;
  }

  .table td .btn {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
  }

  /* Animasi hover untuk tombol aksi */
  .table td .btn {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  .table td .btn:hover {
    transform: scale(1.1);
    /* Membesar sedikit */
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  }

  .table-responsive {
    scrollbar-width: thin;
    /* Firefox */
    scrollbar-color: #bbb #f1f1f1;
    /* Firefox */
  }

  .table-responsive::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  .table-responsive::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 8px;
  }

  .table-responsive::-webkit-scrollbar-thumb {
    background-color: #bbb;
    border-radius: 8px;
    border: 2px solid #f1f1f1;
  }
</style>

<script>
  document.getElementById("btnBayar")?.addEventListener("click", function(e) {
    Swal.fire({
      title: 'Konfirmasi Pembayaran',
      text: "Apakah Anda yakin sudah membayar semua belanjaan?",
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, Bayar',
      cancelButtonText: 'Batal'
    }).then((result) => {
      if (result.isConfirmed) {
        // Redirect ke proses bayar
        window.location.href = "proses.php?bayar=1";
      }
    })
  });
</script>

<script>
  document.querySelectorAll('.btn-hapus').forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const id = this.dataset.id;
      Swal.fire({
        title: 'Hapus Barang?',
        text: "Apakah Anda yakin ingin menghapus item ini?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
          // Redirect ke proses hapus
          window.location.href = "proses.php?hapus=" + id;
        }
      });
    });
  });

  document.getElementById('btnKosongkan')?.addEventListener('click', function(e) {
    e.preventDefault();
    Swal.fire({
      title: 'Kosongkan Daftar?',
      text: "Semua item di daftar belanja akan dihapus.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Ya, Kosongkan',
      cancelButtonText: 'Batal'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = "proses.php?kosongkan=1";
      }
    });
  });

  // Pencarian real-time
  document.getElementById('cariBarang')?.addEventListener('input', function() {
    const keyword = this.value.toLowerCase();
    const rows = document.querySelectorAll('#tabelBelanja tr');
    let adaHasil = false;
    rows.forEach(row => {
      const namaBarang = row.querySelector('td:nth-child(2)');
      if (!namaBarang) return;
      const cocok = namaBarang.textContent.toLowerCase().includes(keyword);
      row.style.display = cocok ? '' : 'none';
      if (cocok) adaHasil = true;
    });
    // Tampilkan pesan jika tidak ada hasil
    let kosong = document.getElementById('hasilKosong');
    if (!adaHasil && keyword !== '') {
      if (!kosong) {
        kosong = document.createElement('tr');
        kosong.id = 'hasilKosong';
        kosong.innerHTML = "<td colspan='5' class='text-center text-muted py-3'>Barang tidak ditemukan.</td>";
        document.getElementById('tabelBelanja').appendChild(kosong);
      }
    } else if (kosong) {
      kosong.remove();
    }
  });
</script>
-- =========================
-- TABEL USERS
-- =========================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    budget_bulanan DECIMAL(15,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- TABEL DAFTAR_BELANJA
-- =========================
CREATE TABLE IF NOT EXISTS daftar_belanja (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    jumlah_satuan VARCHAR(50) NOT NULL,
    harga DOUBLE NOT NULL,
    kategori VARCHAR(50) DEFAULT 'Lainnya',
    status ENUM('belum', 'selesai', 'dibayar') DEFAULT 'belum',
    waktu_selesai DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =========================
-- ALTER (jika database sudah ada)
-- Jalankan ini jika tabel sudah terlanjur dibuat tanpa kolom baru
-- =========================
-- ALTER TABLE daftar_belanja ADD COLUMN IF NOT EXISTS kategori VARCHAR(50) DEFAULT 'Lainnya';
-- ALTER TABLE users ADD COLUMN IF NOT EXISTS budget_bulanan DECIMAL(15,2) DEFAULT 0;
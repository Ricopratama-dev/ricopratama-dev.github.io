<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'includes/koneksi.php';

$user_id = $_SESSION['user_id'];

// Ambil data user
$stmt = $conn->prepare("SELECT nama, email, created_at, budget_bulanan FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Proses simpan budget
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['budget_bulanan'])) {
    $budget = (float)$_POST['budget_bulanan'];
    $upd = $conn->prepare("UPDATE users SET budget_bulanan=? WHERE id=?");
    $upd->bind_param("di", $budget, $user_id);
    $upd->execute();
    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Budget berhasil disimpan!'];
    header("Location: profil.php");
    exit;
}

include 'includes/header.php';
?>

<div class="row justify-content-center g-4">

  <!-- Kartu Info Akun -->
  <div class="col-md-5">
    <div class="card border-0 shadow-lg rounded-4 h-100">
      <div class="card-body p-4">
        <div class="text-center mb-4">
          <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center mb-3"
            style="width:72px;height:72px;font-size:2rem;">
            <i class="bi bi-person-fill"></i>
          </div>
          <h5 class="fw-bold mb-1"><?= htmlspecialchars($user['nama']) ?></h5>
          <p class="text-muted small mb-0"><?= htmlspecialchars($user['email']) ?></p>
        </div>
        <hr>
        <ul class="list-unstyled small text-muted mb-0">
          <li class="mb-2">
            <i class="bi bi-calendar3 me-2"></i>
            Bergabung sejak <?= date('d F Y', strtotime($user['created_at'])) ?>
          </li>
          <li>
            <i class="bi bi-shield-check me-2 text-success"></i>
            Akun aktif
          </li>
        </ul>
      </div>
    </div>
  </div>

  <!-- Kartu Budget Bulanan -->
  <div class="col-md-10">
    <div class="card border-0 shadow-lg rounded-4">
      <div class="card-body p-4">
        <h5 class="fw-bold mb-1">Budget Belanja Bulanan</h5>
        <p class="text-muted small mb-4">Atur batas pengeluaran per bulan. Peringatan akan muncul jika mendekati atau melebihi budget.</p>
        <form method="POST">
          <div class="row g-3 align-items-end">
            <div class="col-md-8">
              <div class="form-floating">
                <input type="number" class="form-control rounded-3" id="budget_bulanan"
                  name="budget_bulanan" placeholder="Budget"
                  value="<?= $user['budget_bulanan'] ?? 0 ?>" min="0" step="1000">
                <label for="budget_bulanan">Budget (Rp) — isi 0 untuk nonaktifkan</label>
              </div>
            </div>
            <div class="col-md-4">
              <button type="submit" class="btn btn-primary w-100 rounded-3 py-2">
                <i class="bi bi-piggy-bank me-1"></i> Simpan Budget
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

</div>

<?php include 'includes/footer.php'; ?>
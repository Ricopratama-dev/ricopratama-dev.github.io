<?php
session_start();
include 'includes/koneksi.php';

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $konfirmasi = $_POST['konfirmasi_password'];

    if (strlen($nama) < 3) {
        $error = "Nama lengkap minimal 3 karakter.";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter.";
    } elseif ($password !== $konfirmasi) {
        $error = "Konfirmasi password tidak cocok.";
    } else {
        // cek apakah email sudah terdaftar
        $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Email sudah terdaftar!";
        } else {
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO users (nama, email, password) VALUES (?,?,?)");
            $stmt->bind_param("sss", $nama, $email, $hashed);

            if ($stmt->execute()) {
                $success = "Registrasi berhasil! Silakan <a href='login.php'>login</a>.";
            } else {
                $error = "Terjadi kesalahan saat registrasi.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register - Sistem Belanja</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #C6E6F1, #94CDE6);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    padding: 20px;
    animation: fadeInBody 1s ease forwards;
}

@keyframes fadeInBody {
    0% { opacity: 0; }
    100% { opacity: 1; }
}

.container {
    display: flex;
    width: 100%;
    max-width: 900px;
    min-height: 500px;
    background: #fff;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    flex-wrap: wrap;
    animation: fadeInContainer 1s ease forwards;
}

@keyframes fadeInContainer {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
}

/* Welcome section */
.welcome-section {
    flex: 1 1 300px;
    background: linear-gradient(135deg, #5EA1C5, #3A75A2);
    color: #fff;
    padding: 60px 30px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    min-width: 300px;
    opacity: 0;
    animation: slideUpWelcome 1s ease forwards;
    animation-delay: 0.2s;
}

@keyframes slideUpWelcome {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
}

.welcome-section h1 { font-size: 32px; font-weight: 700; margin-bottom: 15px; }
.welcome-section p { font-size: 18px; font-weight: 500; }

/* Register section */
.register-section {
    flex: 1 1 300px;
    padding: 60px 30px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    min-width: 300px;
    opacity: 0;
    animation: slideUpRegister 1s ease forwards;
    animation-delay: 0.4s;
}

@keyframes slideUpRegister {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
}

.register-section h2 {
    color: #134573;
    font-size: 28px;
    margin-bottom: 15px;
    font-weight: 600;
    text-align: center;
}

.register-section .error-message {
    background: #f8d7da;
    color: #721c24;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 15px;
    font-size: 14px;
    text-align: center;
}

.register-section .success-message {
    background: #d4edda;
    color: #155724;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 15px;
    font-size: 14px;
    text-align: center;
}

.register-section form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.register-section form input {
    width: 100%;
    max-width: 300px;
    padding: 12px 40px;
    margin: 10px 0;
    border: 2px solid #5EA1C5;
    border-radius: 10px;
    font-size: 16px;
    outline: none;
    transition: all 0.3s ease;
}

.register-section form input:focus {
    border-color: #3A75A2;
    box-shadow: 0 0 12px #94CDE6;
    transform: scale(1.02);
}

.register-section form button {
    width: 100%;
    max-width: 300px;
    padding: 12px;
    background: linear-gradient(90deg, #5EA1C5, #3A75A2);
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 18px;
    cursor: pointer;
    margin-top: 15px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.register-section form button:hover {
    background: linear-gradient(90deg, #3A75A2, #134573);
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.register-section p { margin-top: 20px; font-size: 14px; color: #134573; text-align: center; }
.register-section a { color: #5EA1C5; text-decoration: none; font-weight: 500; }
.register-section a:hover { text-decoration: underline; }

/* Responsive */
@media (max-width: 768px) {
    .container { flex-direction: column; min-height: auto; }
    .welcome-section, .register-section { padding: 40px 20px; }
    .welcome-section h1 { font-size: 28px; }
    .welcome-section p { font-size: 16px; }
    .register-section h2 { font-size: 24px; }
}

@media (max-width: 480px) {
    .welcome-section {
        height: 200px;
        padding: 20px 15px;
        justify-content: center;
    }
    .welcome-section h1 { font-size: 22px; }
    .welcome-section p { font-size: 14px; }
    .register-section { padding: 30px 15px; }
    .register-section h2 { font-size: 20px; }

    .register-section form input,
    .register-section form button {
        width: 300px;
        max-width: 350px;
        font-size: 14px;
        padding: 12px;
    }
}
</style>
</head>
<body>
<div class="container">
    <div class="welcome-section">
        <h1>Selamat Datang!</h1>
        <p>Buat akun untuk memulai pengalaman pencatatan daftar belanja</p>
    </div>
    <div class="register-section">
        <h2>Register</h2>
        <?php if($error): ?>
            <div class="error-message"><?= $error ?></div>
        <?php endif; ?>
        <?php if($success): ?>
            <div class="success-message"><?= $success ?></div>
        <?php endif; ?>
        <form method="post">
            <input type="text" name="nama" placeholder="Nama Lengkap" minlength="3" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password (min. 6 karakter)" minlength="6" required>
            <input type="password" name="konfirmasi_password" placeholder="Konfirmasi Password" required>
            <button type="submit">Register</button>
        </form>
        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>
</div>
</body>
</html>
<?php
$host = "sql308.infinityfree.com";
$user = "if0_41562529";     // default XAMPP
$pass = "XrhvxXyDad1F";         // default XAMPP kosong
$db   = "if0_41562529_db_belanja";  // nama database kamu

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>

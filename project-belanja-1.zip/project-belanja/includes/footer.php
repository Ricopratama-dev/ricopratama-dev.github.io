</main>

  <!-- Modal Logout -->
  <div class="modal fade" id="logoutModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content rounded-4 shadow">
        <div class="modal-header">
          <i class="bi bi-exclamation-triangle-fill"></i>
          <h5 class="modal-title fw-bold text-danger">Yakin mau logout?</h5>
        </div>
        <div class="modal-body text-center text-muted">
          Setelah logout, Anda harus login kembali untuk mengakses aplikasi.
        </div>
        <div class="modal-footer border-0 justify-content-center">
          <button type="button" class="btn btn-cancel btn-outline-secondary px-4" data-bs-dismiss="modal">
            <i class="bi bi-x-circle me-1"></i> Batal
          </button>
          <a href="logout.php" class="btn btn-logout px-4">
            <i class="bi bi-box-arrow-right me-1"></i> Logout
          </a>
        </div>
      </div>
    </div>
  </div>


  <!-- Footer -->
  <footer class="footer mt-auto">
    <div class="container">
      <span>&copy; <?= date('Y') ?> Daftar Belanja</span>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <?php if (!empty($_SESSION['flash'])): ?>
  <script>
    Swal.fire({
      icon: '<?= $_SESSION['flash']['type'] === 'success' ? 'success' : 'error' ?>',
      title: '<?= $_SESSION['flash']['type'] === 'success' ? 'Berhasil!' : 'Oops!' ?>',
      text: '<?= addslashes($_SESSION['flash']['msg']) ?>',
      timer: 2500,
      showConfirmButton: false,
      toast: true,
      position: 'top-end'
    });
  </script>
  <?php unset($_SESSION['flash']); endif; ?>
  </body>
  </html>
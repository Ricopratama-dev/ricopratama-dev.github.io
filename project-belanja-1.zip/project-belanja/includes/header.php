<?php
if (session_status() == PHP_SESSION_NONE) {
  session_start();
}
$halaman_aktif = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Aplikasi Belanja</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    html,
    body {
      height: 100%;
      margin: 0;
    }

    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    main {
      flex: 1 0 auto;
      /* isi ruang tersisa */
      padding: 2rem 1rem;
    }

    footer.footer {
      background-color: #ffffff;
      border-top: 1px solid #e9ecef;
      box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.03);
      text-align: center;
      padding: 1rem 0;
      color: #6c757d;
      flex-shrink: 0;
      /* agar tidak ikut naik */
    }

    .table-responsive-scroll {
      max-height: 250px;
      overflow-y: auto;
    }
  </style>

</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg custom-navbar sticky-top">
    <div class="container">
      <!-- Brand -->
      <a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
        <i class="bi bi-cart4 me-2"></i> Belanja<span class="text-gradient">App</span>
      </a>

      <!-- Hamburger (mobile only) -->
      <button class="navbar-toggler border-0 shadow-none d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarMenu">
        <i class="bi bi-list fs-2"></i>
      </button>

      <!-- Desktop Menu -->
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3 d-none d-lg-flex">
        <li class="nav-item">
          <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'index.php' ? 'active fw-semibold' : '' ?>" href="index.php">
            <i class="bi bi-bag me-1"></i> Belanja
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'history.php' ? 'active fw-semibold' : '' ?>" href="history.php">
            <i class="bi bi-clock-history me-1"></i> Riwayat
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'laporan_pengeluaran.php' ? 'active fw-semibold' : '' ?>" href="laporan_pengeluaran.php">
            <i class="bi bi-file-earmark-bar-graph me-1"></i> Pengeluaran
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'laporan_selisih.php' ? 'active fw-semibold' : '' ?>" href="laporan_selisih.php">
            <i class="bi bi-file-earmark-diff me-1"></i> Selisih
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle d-flex align-items-center <?= $halaman_aktif == 'profil.php' ? 'active fw-semibold' : '' ?>" href="javascript:void(0)" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle me-1"></i> Profil
          </a>
          <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3 p-2">
            <li><a class="dropdown-item rounded-2 <?= $halaman_aktif == 'profil.php' ? 'active' : '' ?>" href="profil.php"><i class="bi bi-person me-2"></i>Lihat Profil</a></li>
            <li><hr class="dropdown-divider"></li>
            <li>
              <a class="dropdown-item rounded-2 text-danger d-flex align-items-center"
                href="#"
                data-bs-toggle="modal"
                data-bs-target="#logoutModal">
                <i class="bi bi-box-arrow-right me-2"></i> Logout
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Offcanvas Sidebar (Mobile) -->
  <div class="offcanvas offcanvas-start custom-offcanvas" tabindex="-1" id="sidebarMenu">
    <div class="offcanvas-header border-bottom">
      <h5 class="offcanvas-title fw-bold"><i class="bi bi-cart4 me-2"></i> Menu</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column gap-3">
      <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'profil.php' ? 'active fw-semibold' : '' ?>" href="profil.php">
        <i class="bi bi-person-circle me-2"></i> Profil
      </a>
      <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'index.php' ? 'active fw-semibold' : '' ?>" href="index.php">
        <i class="bi bi-bag me-2"></i> Belanja
      </a>
      <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'history.php' ? 'active fw-semibold' : '' ?>" href="history.php">
        <i class="bi bi-clock-history me-2"></i> Riwayat
      </a>
      <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'laporan_pengeluaran.php' ? 'active fw-semibold' : '' ?>" href="laporan_pengeluaran.php">
        <i class="bi bi-file-earmark-bar-graph me-2"></i> Pengeluaran
      </a>
      <a class="nav-link d-flex align-items-center <?= $halaman_aktif == 'laporan_selisih.php' ? 'active fw-semibold' : '' ?>" href="laporan_selisih.php">
        <i class="bi bi-file-earmark-diff me-2"></i> Selisih
      </a>
      <a class="btn btn-gradient rounded-pill px-3 d-flex align-items-center"
        href="#"
        data-bs-toggle="modal"
        data-bs-target="#logoutModal">
        <i class="bi bi-box-arrow-right me-2"></i> Logout
      </a>

    </div>
  </div>

  <main class="container my-4">
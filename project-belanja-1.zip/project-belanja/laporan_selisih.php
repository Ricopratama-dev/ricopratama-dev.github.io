<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'includes/koneksi.php';
include 'includes/header.php';

$user_id = $_SESSION['user_id'];

// Tentukan bulan ini & bulan sebelumnya
$bulan_ini = date('Y-m');
$bulan_sebelumnya = date('Y-m', strtotime('-1 month'));

// Ambil total bulan ini
$stmt = $conn->prepare("SELECT SUM(harga) as total FROM daftar_belanja 
                        WHERE user_id=? AND status='dibayar' 
                        AND DATE_FORMAT(waktu_selesai, '%Y-%m')=?");
$stmt->bind_param("is", $user_id, $bulan_ini);
$stmt->execute();
$total_ini = $stmt->get_result()->fetch_assoc()['total'] ?? 0;

// Ambil total bulan sebelumnya
$stmt2 = $conn->prepare("SELECT SUM(harga) as total FROM daftar_belanja 
                         WHERE user_id=? AND status='dibayar' 
                         AND DATE_FORMAT(waktu_selesai, '%Y-%m')=?");
$stmt2->bind_param("is", $user_id, $bulan_sebelumnya);
$stmt2->execute();
$total_lalu = $stmt2->get_result()->fetch_assoc()['total'] ?? 0;

// Hitung selisih
$selisih = $total_ini - $total_lalu;
$status = $selisih > 0 ? "Naik" : ($selisih < 0 ? "Turun" : "Tetap");
$warnaSelisih = $selisih > 0 ? "text-danger" : ($selisih < 0 ? "text-success" : "text-secondary");
$icon = $selisih > 0 ? "▲" : ($selisih < 0 ? "▼" : "■");

// Tren 6 bulan terakhir
$labelTren = [];
$dataTren  = [];
for ($i = 5; $i >= 0; $i--) {
    $bln = date('Y-m', strtotime("-$i month"));
    $labelTren[] = date('M Y', strtotime("-$i month"));
    $stmtT = $conn->prepare("SELECT COALESCE(SUM(harga),0) as total FROM daftar_belanja WHERE user_id=? AND status='dibayar' AND DATE_FORMAT(waktu_selesai,'%Y-%m')=?");
    $stmtT->bind_param("is", $user_id, $bln);
    $stmtT->execute();
    $dataTren[] = (float)$stmtT->get_result()->fetch_assoc()['total'];
}
$labelTrenJson = json_encode($labelTren);
$dataTrenJson  = json_encode($dataTren);
?>

<style>
    body {
        background: #f9fafc;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .stat-card {
        border-radius: 16px;
        padding: 24px;
        text-align: center;
        background: white;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        transition: transform 0.2s ease;
    }

    .stat-card:hover {
        transform: translateY(-4px);
    }

    .stat-value {
        font-size: 1.6rem;
        font-weight: bold;
    }

    .stat-label {
        font-size: 0.9rem;
        color: #777;
    }

    .table-modern th {
        background: #f0f4f8;
        border: none;
    }

    .table-modern td {
        border: none;
        border-bottom: 1px solid #f0f0f0;
    }

    .card-header {
        border-radius: 12px 12px 0 0 !important;
        font-weight: bold;
    }
</style>

<div class="container my-5">
    <div class="text-center mb-5">
        <h1 class="fw-bold">Laporan Selisih Pengeluaran</h1>
        <p class="text-muted">Perbandingan bulan <?= date("F Y", strtotime($bulan_sebelumnya)) ?> dengan <?= date("F Y") ?></p>
    </div>

    <!-- Ringkasan dalam stat cards -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-label">Bulan Ini</div>
                <div class="stat-value text-success">Rp <?= number_format($total_ini, 0, ',', '.') ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-label">Bulan Lalu</div>
                <div class="stat-value text-warning">Rp <?= number_format($total_lalu, 0, ',', '.') ?></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <div class="stat-label">Selisih</div>
                <div class="stat-value <?= $warnaSelisih ?>">
                    <?= $icon ?> Rp <?= number_format(abs($selisih), 0, ',', '.') ?>
                </div>
                <small class="d-block mt-2 text-muted"><?= $status ?> dibanding bulan lalu</small>
            </div>
        </div>
    </div>

    <!-- Grafik -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-gradient bg-info text-white">Grafik Perbandingan Bulan Ini vs Bulan Lalu</div>
        <div class="card-body">
            <canvas id="grafikSelisih" height="120"></canvas>
        </div>
    </div>

    <!-- Grafik Tren 6 Bulan -->
    <div class="card shadow-sm border-0 mb-5">
        <div class="card-header bg-gradient bg-primary text-white">Tren Pengeluaran 6 Bulan Terakhir</div>
        <div class="card-body">
            <canvas id="grafikTren" height="120"></canvas>
        </div>
    </div>

    <!-- Detail Tabel -->
    <div class="row g-4">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-success text-white">Detail Bulan Ini</div>
                <div class="card-body">
                    <?php
                    $stmt3 = $conn->prepare("SELECT nama_barang, jumlah_satuan, harga FROM daftar_belanja
                                              WHERE user_id=? AND status='dibayar' 
                                              AND DATE_FORMAT(waktu_selesai, '%Y-%m')=?");
                    $stmt3->bind_param("is", $user_id, $bulan_ini);
                    $stmt3->execute();
                    $result_ini = $stmt3->get_result();
                    ?>
                    <?php if ($result_ini->num_rows > 0): ?>
                        <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                            <table class="table table-modern align-middle">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th class="text-start">Nama Barang</th>
                                        <th>Jumlah</th>
                                        <th>Harga</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    while ($row = $result_ini->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td class="text-start"><?= htmlspecialchars($row['nama_barang']) ?></td>
                                            <td class="text-center"><?= htmlspecialchars($row['jumlah_satuan']) ?></td>
                                            <td class="text-end">Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Belum ada data bulan ini.</p>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-warning text-white">Detail Bulan Lalu</div>
                <div class="card-body">
                    <?php
                    $stmt4 = $conn->prepare("SELECT nama_barang, jumlah_satuan, harga FROM daftar_belanja
                                              WHERE user_id=? AND status='dibayar' 
                                              AND DATE_FORMAT(waktu_selesai, '%Y-%m')=?");
                    $stmt4->bind_param("is", $user_id, $bulan_sebelumnya);
                    $stmt4->execute();
                    $result_lalu = $stmt4->get_result();
                    ?>
                    <?php if ($result_lalu->num_rows > 0): ?>
                        <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                            <table class="table table-modern align-middle">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th class="text-start">Nama Barang</th>
                                        <th>Jumlah</th>
                                        <th>Harga</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 1;
                                    while ($row = $result_lalu->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= $no++ ?></td>
                                            <td class="text-start"><?= htmlspecialchars($row['nama_barang']) ?></td>
                                            <td class="text-center"><?= htmlspecialchars($row['jumlah_satuan']) ?></td>
                                            <td class="text-end">Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Belum ada data bulan lalu.</p>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('grafikSelisih').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["<?= date("F Y", strtotime($bulan_sebelumnya)) ?>", "<?= date("F Y") ?>"],
            datasets: [{
                data: [<?= $total_lalu ?>, <?= $total_ini ?>],
                backgroundColor: ['#f39c12', '#2ecc71'],
                borderRadius: 12,
            }]
        },
        options: {
            responsive: true,
            animation: {
                duration: 1800,
                easing: 'easeOutQuart'
            },
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });

    // Grafik Tren 6 Bulan
    const ctxTren = document.getElementById('grafikTren').getContext('2d');
    new Chart(ctxTren, {
        type: 'line',
        data: {
            labels: <?= $labelTrenJson ?>,
            datasets: [{
                label: 'Pengeluaran',
                data: <?= $dataTrenJson ?>,
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78,115,223,0.1)',
                borderWidth: 2,
                pointBackgroundColor: '#4e73df',
                pointRadius: 5,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            animation: { duration: 1800, easing: 'easeOutQuart' },
            plugins: { legend: { display: false } },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });
</script>

<?php include 'includes/footer.php'; ?>
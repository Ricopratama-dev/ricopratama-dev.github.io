<?php
session_start();
include 'includes/koneksi.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// ==================== Tambah Barang ====================
if (isset($_POST['tambah'])) {
    $nama           = trim($_POST['nama_barang']);
    $jumlah_satuan  = trim($_POST['jumlah_satuan']);
    $harga          = (float)$_POST['harga'];
    $kategori       = trim($_POST['kategori'] ?? 'Lainnya');
    $user_id        = $_SESSION['user_id'];

    if ($nama === '' || $jumlah_satuan === '' || $harga <= 0) {
        $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Semua field wajib diisi dengan benar.'];
    } else {
        $stmt = $conn->prepare("INSERT INTO daftar_belanja 
            (user_id, nama_barang, jumlah_satuan, harga, kategori, status) 
            VALUES (?, ?, ?, ?, ?, 'belum')");
        $stmt->bind_param("issds", $user_id, $nama, $jumlah_satuan, $harga, $kategori);
        $stmt->execute();
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Barang berhasil ditambahkan!'];
    }

    header("Location: index.php");
    exit;
}

// ==================== Tandai Selesai ====================
if (isset($_GET['selesai'])) {
    $id      = (int)$_GET['selesai'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE daftar_belanja 
        SET status='selesai', waktu_selesai=NOW() 
        WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();

    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Item ditandai selesai!'];
    header("Location: index.php");
    exit;
}

// ==================== Bayar Semua Invoice ====================
if (isset($_GET['bayar'])) {
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE daftar_belanja 
        SET status='dibayar' 
        WHERE user_id=? AND status='selesai'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Pembayaran berhasil dicatat!'];
    header("Location: history.php");
    exit;
}

// ==================== Hapus Barang ====================
if (isset($_GET['hapus'])) {
    $id      = (int)$_GET['hapus'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("DELETE FROM daftar_belanja 
        WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();

    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Barang berhasil dihapus.'];
    header("Location: index.php");
    exit;
}

// ==================== Kosongkan Semua Daftar ====================
if (isset($_GET['kosongkan'])) {
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("DELETE FROM daftar_belanja 
        WHERE user_id=? AND status='belum'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Daftar belanja berhasil dikosongkan.'];
    header("Location: index.php");
    exit;
}

// Jika tidak ada aksi, kembali ke index
header("Location: index.php");
exit;
?>
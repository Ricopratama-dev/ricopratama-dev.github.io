<?php
session_start();
include 'includes/koneksi.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nama']    = $user['nama'];
            header("Location: index.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Email tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Sistem Belanja</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #C6E6F1, #94CDE6);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    padding: 20px;
    animation: fadeInBody 1s ease forwards;
}

@keyframes fadeInBody {
    0% { opacity: 0; }
    100% { opacity: 1; }
}

.container {
    display: flex;
    width: 100%;
    max-width: 900px;
    min-height: 500px;
    background: #fff;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    flex-wrap: wrap;
    animation: fadeInContainer 1s ease forwards;
}

@keyframes fadeInContainer {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
}

/* Welcome section */
.welcome-section {
    flex: 1 1 300px;
    background: linear-gradient(135deg, #5EA1C5, #3A75A2);
    color: #fff;
    padding: 60px 30px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    min-width: 300px;
    opacity: 0;
    animation: slideUpWelcome 1s ease forwards;
    animation-delay: 0.2s;
}

@keyframes slideUpWelcome {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
}

.welcome-section h1 { font-size: 32px; font-weight: 700; margin-bottom: 15px; }
.welcome-section p { font-size: 18px; font-weight: 500; }

/* Login section */
.login-section {
    flex: 1 1 300px;
    padding: 60px 30px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    min-width: 300px;
    opacity: 0;
    animation: slideUpLogin 1s ease forwards;
    animation-delay: 0.4s;
}

@keyframes slideUpLogin {
    0% { opacity: 0; transform: translateY(30px); }
    100% { opacity: 1; transform: translateY(0); }
}

.login-section h2 {
    color: #134573;
    font-size: 28px;
    margin-bottom: 15px;
    font-weight: 600;
    text-align: center;
}

.login-section .error-message {
    background: #f8d7da;
    color: #721c24;
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 15px;
    font-size: 14px;
    text-align: center;
}

.login-section form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.login-section form input {
    width: 100%;
    max-width: 300px;
    padding: 12px 40px;
    margin: 10px 0;
    border: 2px solid #5EA1C5;
    border-radius: 10px;
    font-size: 16px;
    outline: none;
    transition: all 0.3s ease;
}

.login-section form input:focus {
    border-color: #3A75A2;
    box-shadow: 0 0 12px #94CDE6;
    transform: scale(1.02);
}

.login-section form button {
    width: 100%;
    max-width: 300px;
    padding: 12px;
    background: linear-gradient(90deg, #5EA1C5, #3A75A2);
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 18px;
    cursor: pointer;
    margin-top: 15px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.login-section form button:hover {
    background: linear-gradient(90deg, #3A75A2, #134573);
    transform: scale(1.05);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.login-section p { margin-top: 20px; font-size: 14px; color: #134573; text-align: center; }
.login-section a { color: #5EA1C5; text-decoration: none; font-weight: 500; }
.login-section a:hover { text-decoration: underline; }

/* Responsive */
@media (max-width: 768px) {
    .container { flex-direction: column; min-height: auto; }
    .welcome-section, .login-section { padding: 40px 20px; }
    .welcome-section h1 { font-size: 28px; }
    .welcome-section p { font-size: 16px; }
    .login-section h2 { font-size: 24px; }
}

@media (max-width: 480px) {
    .welcome-section {
        height: 200px;
        padding: 20px 15px;
        justify-content: center;
    }
    .welcome-section h1 { font-size: 22px; }
    .welcome-section p { font-size: 14px; }
    .login-section { padding: 30px 15px; }
    .login-section h2 { font-size: 20px; }

    .login-section form input,
    .login-section form button {
        width: 300px;
        max-width: 350px;
        font-size: 14px;
        padding: 12px;
    }
}
</style>
</head>
<body>
<div class="container">
    <div class="welcome-section">
        <h1>Selamat Datang!</h1>
        <p>Silakan login untuk melanjutkan pengalaman pencatatan daftar belanja</p>
    </div>
    <div class="login-section">
        <h2>Login</h2>
        <?php if($error): ?>
            <div class="error-message"><?= $error ?></div>
        <?php endif; ?>
        <form method="post">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
    </div>
</div>
</body>
</html>

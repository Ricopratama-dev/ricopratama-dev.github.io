<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'includes/koneksi.php';
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
$filter = $_POST['filter'] ?? 'hari';
$tanggal = $_POST['tanggal'] ?? date('Y-m-d');
$minggu_awal = $_POST['minggu_awal'] ?? date('Y-m-d');
$minggu_akhir = $_POST['minggu_akhir'] ?? date('Y-m-d');
$bulan = $_POST['bulan'] ?? date('Y-m');

// Query default
$total = 0;
$data = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($filter == "hari") {
        $stmt = $conn->prepare("SELECT * FROM daftar_belanja 
                                WHERE user_id=? AND status='dibayar' 
                                AND DATE(waktu_selesai)=?");
        $stmt->bind_param("is", $user_id, $tanggal);
    } elseif ($filter == "minggu") {
        $stmt = $conn->prepare("SELECT * FROM daftar_belanja 
                                WHERE user_id=? AND status='dibayar' 
                                AND DATE(waktu_selesai) BETWEEN ? AND ?");
        $stmt->bind_param("iss", $user_id, $minggu_awal, $minggu_akhir);
    } elseif ($filter == "bulan") {
        $stmt = $conn->prepare("SELECT * FROM daftar_belanja 
                                WHERE user_id=? AND status='dibayar' 
                                AND DATE_FORMAT(waktu_selesai, '%Y-%m')=?");
        $stmt->bind_param("is", $user_id, $bulan);
    }

    if (isset($stmt)) {
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
            $total += $row['harga'];
        }
    }
}
?>

<div class="container my-5">
    <div class="text-center mb-4">
        <h1 class="fw-bold" style="color: var(--c5);">Laporan Pengeluaran</h1>
        <p class="text-muted">Kelola dan analisis pengeluaran Anda dengan mudah</p>
    </div>

    <!-- Filter Card -->
    <form method="POST" class="card border-0 shadow p-4 mb-5 rounded-4 bg-light">
        <div class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-semibold">Jenis Laporan</label>
                <select name="filter" class="form-select shadow-sm" onchange="this.form.submit()">
                    <option value="hari" <?= $filter == 'hari' ? 'selected' : '' ?>>Per Hari</option>
                    <option value="minggu" <?= $filter == 'minggu' ? 'selected' : '' ?>>Per Minggu</option>
                    <option value="bulan" <?= $filter == 'bulan' ? 'selected' : '' ?>>Per Bulan</option>
                </select>
            </div>

            <?php if ($filter == "hari"): ?>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Tanggal</label>
                    <input type="date" name="tanggal" value="<?= $tanggal ?>" class="form-control shadow-sm" onchange="this.form.submit()">
                </div>
            <?php elseif ($filter == "minggu"): ?>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Dari</label>
                    <input type="date" name="minggu_awal" value="<?= $minggu_awal ?>" class="form-control shadow-sm" onchange="this.form.submit()">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Sampai</label>
                    <input type="date" name="minggu_akhir" value="<?= $minggu_akhir ?>" class="form-control shadow-sm" onchange="this.form.submit()">
                </div>
            <?php elseif ($filter == "bulan"): ?>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Bulan</label>
                    <input type="month" name="bulan" value="<?= $bulan ?>" class="form-control shadow-sm" onchange="this.form.submit()">
                </div>
            <?php endif; ?>

            <div class="col-md-2 d-grid">
                <button type="submit" class="btn text-white fw-semibold shadow-sm" style="background: var(--c5);">
                    Tampilkan
                </button>
            </div>
        </div>
    </form>

    <!-- Hasil Laporan -->
    <div class="card border-0 shadow rounded-4 overflow-hidden">
        <div class="card-header text-white fw-bold" style="background: var(--c5);">
            Hasil Laporan
        </div>
        <div class="card-body">
            <?php if (!empty($data)): ?>
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table align-middle table-hover">
                        <thead style="background: var(--c1);">
                            <tr class="text-center">
                                <th>No</th>
                                <th class="text-start">Nama Barang</th>
                                <th>Jumlah</th>
                                <th class="text-end">Harga</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($data as $d): ?>
                                <tr>
                                    <td class="text-center"><?= $no++ ?></td>
                                    <td class="text-start"><?= htmlspecialchars($d['nama_barang']) ?></td>
                                    <td class="text-center"><?= htmlspecialchars($d['jumlah_satuan']) ?></td>
                                    <td class="text-end">Rp <?= number_format($d['harga'], 0, ',', '.') ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <tr class="fw-bold table-light">
                                <td colspan="3" class="text-end">Total</td>
                                <td class="text-end text-success">Rp <?= number_format($total, 0, ',', '.') ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Card Total -->
                <div class="alert mt-4 text-center fw-bold shadow-sm" style="background: var(--c1); color: var(--c5); font-size: 1.2rem;">
                    💰 Total Pengeluaran: Rp <?= number_format($total, 0, ',', '.') ?>
                </div>

                <!-- Tombol Export -->
                <div class="d-flex gap-2 justify-content-end mt-3">
                    <button id="btnExportCSV" class="btn btn-outline-success rounded-pill px-4">
                        <i class="bi bi-filetype-csv me-1"></i> Export CSV
                    </button>
                    <button id="btnExportPDF" class="btn btn-outline-danger rounded-pill px-4">
                        <i class="bi bi-filetype-pdf me-1"></i> Export PDF
                    </button>
                </div>

                <!-- Data tersembunyi untuk export -->
                <div id="exportData" style="display:none"
                    data-filter="<?= htmlspecialchars($filter) ?>"
                    data-total="<?= $total ?>">
                    <?php foreach ($data as $d): ?>
                    <span class="export-row"
                        data-nama="<?= htmlspecialchars($d['nama_barang']) ?>"
                        data-jumlah="<?= htmlspecialchars($d['jumlah_satuan']) ?>"
                        data-harga="<?= $d['harga'] ?>"></span>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-folder-x fs-1 d-block mb-2"></i>
                    Belum ada data untuk filter ini.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    .form-select,
    .form-control {
        border-radius: 12px;
    }

    .table th,
    .table td {
        vertical-align: middle;
        padding: 12px 16px;
    }

    .table-hover tbody tr:hover {
        background-color: #f9fcff;
        transition: background 0.3s ease;
    }
</style>

<script src="https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jspdf-autotable@3.8.2/dist/jspdf.plugin.autotable.min.js"></script>
<script>
function getExportData() {
    const rows = document.querySelectorAll('.export-row');
    return Array.from(rows).map((r, i) => ({
        no: i + 1,
        nama: r.dataset.nama,
        jumlah: r.dataset.jumlah,
        harga: parseFloat(r.dataset.harga)
    }));
}

function formatRp(val) {
    return 'Rp ' + val.toLocaleString('id-ID');
}

// Export CSV
document.getElementById('btnExportCSV')?.addEventListener('click', function() {
    const rows = getExportData();
    const total = parseFloat(document.getElementById('exportData').dataset.total);
    let csv = 'No,Nama Barang,Jumlah,Harga\n';
    rows.forEach(r => {
        csv += `${r.no},"${r.nama}","${r.jumlah}",${r.harga}\n`;
    });
    csv += `,,Total,${total}\n`;
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'laporan_pengeluaran.csv';
    a.click();
    URL.revokeObjectURL(url);
});

// Export PDF
document.getElementById('btnExportPDF')?.addEventListener('click', function() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const rows = getExportData();
    const total = parseFloat(document.getElementById('exportData').dataset.total);

    doc.setFontSize(14);
    doc.text('Laporan Pengeluaran', 14, 18);
    doc.setFontSize(10);
    doc.setTextColor(120);
    doc.text('Dicetak: ' + new Date().toLocaleDateString('id-ID'), 14, 26);
    doc.setTextColor(0);

    const tableRows = rows.map(r => [r.no, r.nama, r.jumlah, formatRp(r.harga)]);
    tableRows.push(['', '', 'Total', formatRp(total)]);

    doc.autoTable({
        head: [['No', 'Nama Barang', 'Jumlah', 'Harga']],
        body: tableRows,
        startY: 32,
        styles: { fontSize: 10 },
        headStyles: { fillColor: [78, 115, 223] },
        didParseCell: function(data) {
            if (data.row.index === tableRows.length - 1) {
                data.cell.styles.fontStyle = 'bold';
            }
        }
    });

    doc.save('laporan_pengeluaran.pdf');
});
</script>

<?php include 'includes/footer.php'; ?>
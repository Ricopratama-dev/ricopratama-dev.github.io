<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'includes/koneksi.php';

$user_id = $_SESSION['user_id'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil data barang milik user ini
$stmt = $conn->prepare("SELECT * FROM daftar_belanja WHERE id=? AND user_id=? AND status='belum'");
$stmt->bind_param("ii", $id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$barang = $result->fetch_assoc();

// Jika data tidak ditemukan, kembali ke index
if (!$barang) {
    header("Location: index.php");
    exit;
}

// Proses simpan edit
$error = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama          = trim($_POST['nama_barang']);
    $jumlah_satuan = trim($_POST['jumlah_satuan']);
    $harga         = (float)$_POST['harga'];

    if ($nama === '' || $jumlah_satuan === '' || $harga <= 0) {
        $error = "Semua field wajib diisi dengan benar.";
    } else {
        $kategori = trim($_POST['kategori'] ?? 'Lainnya');
        $upd = $conn->prepare("UPDATE daftar_belanja SET nama_barang=?, jumlah_satuan=?, harga=?, kategori=? WHERE id=? AND user_id=?");
        $upd->bind_param("ssdsii", $nama, $jumlah_satuan, $harga, $kategori, $id, $user_id);
        $upd->execute();
        header("Location: index.php");
        exit;
    }
}

include 'includes/header.php';
?>

<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card border-0 shadow-lg rounded-4">
      <div class="card-body p-4">
        <div class="mb-4">
          <h5 class="fw-bold mb-1">Edit Item Belanja</h5>
          <p class="text-muted small mb-0">Ubah detail barang yang sudah ditambahkan</p>
        </div>

        <?php if ($error): ?>
          <div class="alert alert-danger rounded-3"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
          <div class="form-floating mb-3">
            <input type="text" class="form-control rounded-3" id="nama_barang" name="nama_barang"
              placeholder="Nama Barang" value="<?= htmlspecialchars($barang['nama_barang']) ?>" required>
            <label for="nama_barang">Nama Barang</label>
          </div>
          <div class="form-floating mb-3">
            <input type="text" class="form-control rounded-3" id="jumlah_satuan" name="jumlah_satuan"
              placeholder="Contoh: 2 kg" value="<?= htmlspecialchars($barang['jumlah_satuan']) ?>" required>
            <label for="jumlah_satuan">Jumlah & Satuan</label>
          </div>
          <div class="form-floating mb-4">
            <input type="number" class="form-control rounded-3" id="harga" name="harga"
              step="0.01" placeholder="Harga" value="<?= $barang['harga'] ?>" required>
            <label for="harga">Harga Total</label>
          </div>
          <div class="form-floating mb-4">
            <select class="form-select rounded-3" id="kategori" name="kategori">
              <?php
              $kategoriList = ['Makanan','Minuman','Kebutuhan Rumah','Kebersihan','Kesehatan','Pakaian','Elektronik','Lainnya'];
              foreach ($kategoriList as $kat):
                $sel = ($barang['kategori'] ?? 'Lainnya') === $kat ? 'selected' : '';
              ?>
                <option value="<?= $kat ?>" <?= $sel ?>><?= $kat ?></option>
              <?php endforeach; ?>
            </select>
            <label for="kategori">Kategori</label>
          </div>
          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-success rounded-3 px-4 py-2 flex-grow-1">
              <i class="bi bi-check-circle me-1"></i> Simpan Perubahan
            </button>
            <a href="index.php" class="btn btn-outline-secondary rounded-3 px-4 py-2">
              <i class="bi bi-x-circle me-1"></i> Batal
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
<?php
session_start();
include 'includes/koneksi.php';

// Pastikan user login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'includes/header.php';


$user_id = $_SESSION['user_id'];

// --- Pagination ---
$limit = 5;
$page  = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Ambil daftar waktu_selesai unik (kelompok per menit)
$stmt = $conn->prepare("SELECT DISTINCT DATE_FORMAT(waktu_selesai, '%Y-%m-%d %H:%i') as waktu_invoice
                            FROM daftar_belanja 
                            WHERE user_id=? AND status='dibayar' 
                            ORDER BY waktu_invoice DESC 
                            LIMIT ? OFFSET ?");
$stmt->bind_param("iii", $user_id, $limit, $offset);
$stmt->execute();
$riwayat_waktu = $stmt->get_result();

// Hitung total data
$count = $conn->prepare("SELECT COUNT(DISTINCT DATE_FORMAT(waktu_selesai, '%Y-%m-%d %H:%i')) as total 
                            FROM daftar_belanja 
                            WHERE user_id=? AND status='dibayar'");
$count->bind_param("i", $user_id);
$count->execute();
$total_rows = $count->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);
?>

<div class="container my-5">
    <div class="text-center mb-5">
        <h1 class="fw-bold">Riwayat Belanja</h1>
        <p class="text-muted">Lihat kembali semua invoice pembelian Anda</p>
    </div>

    <?php if ($riwayat_waktu->num_rows > 0): ?>
        <?php $i_card = 1; ?>
        <?php while ($w = $riwayat_waktu->fetch_assoc()): ?>
            <?php
            $waktu_invoice = $w['waktu_invoice'];
            $stmt2 = $conn->prepare("SELECT * FROM daftar_belanja 
                                WHERE user_id=? AND status='dibayar' 
                                AND DATE_FORMAT(waktu_selesai, '%Y-%m-%d %H:%i')=?");
            $stmt2->bind_param("is", $user_id, $waktu_invoice);
            $stmt2->execute();
            $barang = $stmt2->get_result();

            $total = 0;
            $jumlah_item = 0;
            while ($row_temp = $barang->fetch_assoc()) {
                $total += (float)$row_temp['harga'];
                $jumlah_item++;
            }
            $barang->data_seek(0);
            ?>

            <!-- Invoice Card -->
            <div class="invoice-card mb-3 shadow-sm rounded-4 overflow-hidden">
                <div class="invoice-header d-flex justify-content-between align-items-center px-4 py-3"
                    data-bs-toggle="collapse" data-bs-target="#collapse<?= $i_card ?>" style="cursor:pointer;">
                    <div>
                        <h6 class="fw-semibold mb-1">Invoice - <?= date("d M Y H:i", strtotime($waktu_invoice)) ?></h6>
                        <small class="text-muted"><?= $jumlah_item ?> item • Rp <?= number_format($total, 0, ',', '.') ?></small>
                    </div>
                    <button class="btn btn-sm btn-light rounded-pill px-3 d-flex align-items-center gap-1 btn-cetak"
                        data-target="print-area-<?= $i_card ?>"
                        onclick="event.stopPropagation()">
                        <i class="bi bi-printer"></i> Cetak
                    </button>
                </div>
                <div id="collapse<?= $i_card ?>" class="collapse">
                    <div class="p-4">
                        <!-- Area yang akan dicetak -->
                        <div id="print-area-<?= $i_card ?>">
                            <div class="text-center mb-3 d-none d-print-block">
                                <h5 class="fw-bold">Daftar Belanja App</h5>
                                <p class="mb-0 small">Invoice - <?= date("d M Y H:i", strtotime($waktu_invoice)) ?></p>
                                <p class="small text-muted">Dicetak pada: <?= date("d M Y H:i") ?></p>
                                <hr>
                            </div>
                            <div class="table-responsive" style="max-height: 250px; overflow-y: auto;">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-primary text-center">
                                        <tr>
                                            <th style="width: 60px;">No</th>
                                            <th class="text-start">Nama Barang</th>
                                            <th style="width: 120px;">Jumlah</th>
                                            <th style="width: 150px;">Harga</th>
                                        </tr>
                                    </thead>
                                    <tbody class="align-middle">
                                        <?php $no = 1;
                                        while ($row = $barang->fetch_assoc()): ?>
                                            <tr>
                                                <td class="text-center"><?= $no++ ?></td>
                                                <td class="text-start"><?= htmlspecialchars($row['nama_barang']) ?></td>
                                                <td class="text-center"><?= htmlspecialchars($row['jumlah_satuan']) ?></td>
                                                <td class="text-end">Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                                            </tr>
                                        <?php endwhile; ?>
                                        <tr class="fw-bold bg-light">
                                            <td colspan="3" class="text-end">Total</td>
                                            <td class="text-end">Rp <?= number_format($total, 0, ',', '.') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php $i_card++; ?>
        <?php endwhile; ?>

        <!-- Pagination -->
        <nav class="mt-4">
            <ul class="pagination justify-content-center gap-2">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link rounded-pill px-3 <?= $i == $page ? 'bg-primary text-white' : 'text-primary' ?>"
                            href="?page=<?= $i ?>">
                            <?= $i ?>
                        </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>

    <?php else: ?>
        <div class="alert alert-info text-center">
            Belum ada riwayat belanja.
        </div>
    <?php endif; ?>
</div>

<style>
    /* Card Styling */
    .invoice-card {
        border: 1px solid #e9ecef;
        transition: all .2s ease;
    }

    .invoice-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
    }

    /* Header styling */
    .invoice-header {
        background: linear-gradient(135deg, #4e73df, #1cc88a);
        color: white;
        transition: background .3s ease;
    }

    .invoice-header:hover {
        background: linear-gradient(135deg, #1cc88a, #4e73df);
    }



    /* Pagination pill */
    .pagination .page-link {
        border: none;
        font-weight: 500;
    }

    @media print {
        body * { visibility: hidden; }
        #print-content, #print-content * { visibility: visible; }
        #print-content { position: absolute; left: 0; top: 0; width: 100%; }
        .d-print-block { display: block !important; }
    }
</style>

<script>
    document.querySelectorAll('.btn-cetak').forEach(btn => {
        btn.addEventListener('click', function() {
            const targetId = this.dataset.target;
            const area = document.getElementById(targetId);

            // Buka jendela print baru
            const printWin = window.open('', '_blank', 'width=700,height=600');
            printWin.document.write(`
                <html><head>
                <title>Invoice Belanja</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    body { padding: 30px; font-family: Arial, sans-serif; }
                    .text-end { text-align: right; }
                    .text-center { text-align: center; }
                    .text-start { text-align: left; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { padding: 8px 12px; border: 1px solid #dee2e6; }
                    thead { background: #cfe2ff; }
                    .fw-bold { font-weight: bold; }
                    .bg-light { background: #f8f9fa; }
                    hr { border-top: 1px solid #dee2e6; }
                </style>
                </head><body>
                <div class="text-center mb-3">
                    <h5 style="font-weight:bold">Daftar Belanja App</h5>
                    <p style="margin:0">${area.querySelector('p.mb-0') ? area.querySelector('p.mb-0').innerText : ''}</p>
                    <p style="color:#888;font-size:13px">Dicetak pada: ${new Date().toLocaleString('id-ID')}</p>
                    <hr>
                </div>
                ${area.querySelector('.table-responsive').outerHTML}
                </body></html>
            `);
            printWin.document.close();
            printWin.focus();
            printWin.print();
            printWin.close();
        });
    });
</script>



<?php include 'includes/footer.php'; ?>